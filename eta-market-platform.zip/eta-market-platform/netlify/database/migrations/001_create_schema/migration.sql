-- ============================================================
-- ETA MARKET — Schéma de base de données de la plateforme
-- Chaque vendeur possède une boutique, des produits et reçoit
-- des commandes payées via MTN MoMo ou Airtel Money.
-- ============================================================

-- 1. VENDEURS
-- Un vendeur = une personne qui possède une boutique sur la plateforme.
CREATE TABLE vendors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'suspended')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. BOUTIQUES
-- Chaque vendeur a une boutique avec son propre nom, son URL (slug),
-- ses couleurs et son numéro Mobile Money pour être payé.
CREATE TABLE stores (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vendor_id UUID NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,              -- ex: "boutique-marie" -> etamarket.cg/b/boutique-marie
  description TEXT,
  logo_url TEXT,
  accent_color TEXT DEFAULT '#E63946',
  mtn_momo_number TEXT,
  airtel_money_number TEXT,
  city TEXT DEFAULT 'Brazzaville',
  is_published BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_stores_vendor ON stores(vendor_id);
CREATE INDEX idx_stores_slug ON stores(slug);

-- 3. CATÉGORIES (propres à chaque boutique)
CREATE TABLE categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  position INTEGER NOT NULL DEFAULT 0
);

-- 4. PRODUITS
CREATE TABLE products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
  category_id UUID REFERENCES categories(id) ON DELETE SET NULL,
  category TEXT DEFAULT 'tech',           -- version simple: tech / mode / maison (texte libre pour commencer)
  badge TEXT,                             -- 'promo', 'new', ou vide
  name TEXT NOT NULL,
  description TEXT,
  price_fcfa INTEGER NOT NULL CHECK (price_fcfa >= 0),
  compare_at_price_fcfa INTEGER,          -- prix barré, pour affichage promo
  image_url TEXT,
  stock_quantity INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_products_store ON products(store_id);
CREATE INDEX idx_products_category ON products(category_id);

-- 5. COMMANDES
CREATE TABLE orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  delivery_address TEXT,
  total_fcfa INTEGER NOT NULL CHECK (total_fcfa >= 0),
  status TEXT NOT NULL DEFAULT 'pending_payment'
    CHECK (status IN ('pending_payment', 'paid', 'preparing', 'shipped', 'delivered', 'cancelled')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_orders_store ON orders(store_id);
CREATE INDEX idx_orders_status ON orders(status);

-- 6. LIGNES DE COMMANDE (quels produits, en quelle quantité)
CREATE TABLE order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id UUID REFERENCES products(id) ON DELETE SET NULL,
  product_name_snapshot TEXT NOT NULL,   -- on garde le nom même si le produit est modifié/supprimé plus tard
  unit_price_fcfa INTEGER NOT NULL,
  quantity INTEGER NOT NULL CHECK (quantity > 0)
);

CREATE INDEX idx_order_items_order ON order_items(order_id);

-- 7. PAIEMENTS (trace de chaque transaction Mobile Money)
CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  operator TEXT NOT NULL CHECK (operator IN ('mtn_momo', 'airtel_money')),
  payer_phone TEXT NOT NULL,
  amount_fcfa INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'initiated'
    CHECK (status IN ('initiated', 'confirmed', 'failed', 'cancelled')),
  provider_transaction_id TEXT,          -- référence renvoyée par l'API MTN/Airtel
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  confirmed_at TIMESTAMPTZ
);

CREATE INDEX idx_payments_order ON payments(order_id);
