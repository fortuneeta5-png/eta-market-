// netlify/functions/create-store.js
//
// Ce que fait cette fonction, étape par étape :
// 1. Un vendeur remplit un formulaire "Créer ma boutique" côté site
// 2. Le navigateur envoie ces infos ici (POST /.netlify/functions/create-store)
// 3. On vérifie que le nom de boutique (slug) n'est pas déjà pris
// 4. On enregistre la boutique dans la base de données
// 5. On renvoie l'URL de la nouvelle boutique au vendeur

import { getDatabase } from "@netlify/database";

function slugify(text) {
  return text
    .toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "") // enlève les accents
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

export default async (req) => {
  if (req.method !== "POST") {
    return new Response("Méthode non autorisée", { status: 405 });
  }

  try {
    const body = await req.json();
    const { vendorId, storeName, city, mtnMomoNumber, airtelMoneyNumber } = body;

    if (!vendorId || !storeName) {
      return new Response(
        JSON.stringify({ error: "vendorId et storeName sont obligatoires" }),
        { status: 400, headers: { "Content-Type": "application/json" } }
      );
    }

    const db = getDatabase();
    let slug = slugify(storeName);

    // Vérifie l'unicité du slug, ajoute un suffixe si besoin
    const existing = await db.sql`SELECT id FROM stores WHERE slug = ${slug}`;
    if (existing.length > 0) {
      slug = `${slug}-${Math.floor(Math.random() * 1000)}`;
    }

    const [store] = await db.sql`
      INSERT INTO stores (vendor_id, name, slug, city, mtn_momo_number, airtel_money_number)
      VALUES (${vendorId}, ${storeName}, ${slug}, ${city || "Brazzaville"}, ${mtnMomoNumber || null}, ${airtelMoneyNumber || null})
      RETURNING id, name, slug, created_at
    `;

    return new Response(
      JSON.stringify({
        message: "Boutique créée avec succès",
        store,
        storeUrl: `/b/${store.slug}`,
      }),
      { status: 201, headers: { "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: "Erreur serveur", details: String(err) }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }
};
